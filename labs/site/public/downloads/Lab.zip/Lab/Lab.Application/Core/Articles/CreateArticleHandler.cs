﻿using Lab.Application.Common.DataAccess;
using Lab.Application.Common.Errors;
using Lab.Application.Common.Logging;
using Lab.Application.Common.Models;
using Lab.Domain.Common.Exceptions;
using Lab.Domain.Core.Invoices;

namespace Lab.Application.Core.Articles;

public class CreateArticleHandler : ICreateArticleHandler
{
    private readonly ILogger _logger;
    private readonly IUnitOfWork _unitOfWork;

    public CreateArticleHandler(ILogger logger, IUnitOfWork unitOfWork)
    {
        _logger = logger;
        _unitOfWork = unitOfWork;
    }

    public async Task<Response<ArticleModel>> HandleAsync(ArticleModel model, CancellationToken cancellationToken)
    {
        // authentication/authorization
        Response<ArticleModel> response = new();
        try
        {
            // validations
            if (string.IsNullOrWhiteSpace(model.Titlu))
            {
                response.ErrorMessage = "Titlul nu poate fi gol!";
                _logger.Error("Titlul nu poate fi gol");
            }

            InvoiceService invoiceService = new();
            invoiceService.AddInvoice();


            await _unitOfWork.ArticleRepository.AddAsync(model.ToRepository(), cancellationToken);
            await _unitOfWork.SaveChangesAsync();
            response.Data = 
        }
        catch (InvalidDiscountException ex)
        {
            response.ErrorMessage = "Clientul selectat nu poate avea discount";

        }
        catch (Exception ex)
        {
            response.ErrorMessage = "Eroare: " + ex.Message;
            _logger.Error("Eroare: " + ex.Message);
        }
        return response;
    }
}
