﻿using Lab.Application.Common.Errors;
using Lab.Application.Common.Models;

namespace Lab.Application.Core.Articles;

public interface ICreateArticleHandler
{
    Task<Response<ArticleModel>> HandleAsync(ArticleModel model, CancellationToken cancellationToken);
}
