﻿namespace Lab.Application.Common.DataAccess;

public interface IUnitOfWork
{
    IArticleRepository ArticleRepository { get; }
    Task SaveChangesAsync();
}
