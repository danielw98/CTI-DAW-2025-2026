﻿using Lab.Application.Common.DataAccess;

namespace Lab.Application.Common.Entities;

public class ArticleEntity : BaseEntity
{
    public string Titlu { get; set; } = string.Empty;

    public string Content { get; set; } = string.Empty;

    public DateTime PublishedAt { get; set; } = DateTime.Now;

    public int CategoryId { get; set; }
    public CategoryEntity? Category { get; set; }

    public int? UserId { get; set; }
    public UserEntity? User { get; set; }

    public string? ImagePath { get; set; }
}
