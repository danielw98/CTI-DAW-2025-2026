﻿using Lab.Application.Common.Entities;

namespace Lab.Application.Common.DataAccess;

public interface IArticleRepository : IRepository<ArticleEntity>
{
    Task<List<ArticleEntity>> GetAllWithDetailsAsync();
    Task<ArticleEntity?> GetByIdWithDetailsAsync(int id);
    Task<List<ArticleEntity>> GetByCategoryAsync(int categoryId);
}
