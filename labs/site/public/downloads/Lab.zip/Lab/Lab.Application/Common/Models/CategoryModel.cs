﻿namespace Lab.Application.Common.Models;

public class CategoryModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public List<ArticleModel> Articles { get; set; } = [];
}
