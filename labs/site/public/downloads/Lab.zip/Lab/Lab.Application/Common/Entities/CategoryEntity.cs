﻿using Lab.Application.Common.DataAccess;

namespace Lab.Application.Common.Entities;

public class CategoryEntity : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public List<ArticleEntity> Articles { get; set; } = [];
}
