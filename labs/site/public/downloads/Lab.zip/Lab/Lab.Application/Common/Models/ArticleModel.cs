﻿using Lab.Application.Common.Entities;

namespace Lab.Application.Common.Models;

public class ArticleModel
{
    public int Id { get; set; }

    public string Titlu { get; set; } = string.Empty;

    public string Content { get; set; } = string.Empty;

    public DateTime PublishedAt { get; set; } = DateTime.Now;

    public int CategoryId { get; set; }
    public CategoryModel? Category { get; set; }

    public int? UserId { get; set; }
    public UserModel? User { get; set; }

    public string? ImagePath { get; set; }

    internal ArticleEntity ToRepository()
    {
        throw new NotImplementedException();
    }
}
