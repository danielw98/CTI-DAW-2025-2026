﻿namespace Lab.Application.Common.DataAccess;

public class BaseEntity
{
    public int Id { get; set; }
}

