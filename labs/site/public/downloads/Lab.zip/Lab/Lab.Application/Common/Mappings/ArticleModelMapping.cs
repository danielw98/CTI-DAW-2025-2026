﻿using Lab.Application.Common.Entities;
using Lab.Application.Common.Models;

namespace Lab.Application.Common.Mappings;

public static class ArticleModelMapping
{
    public static ArticleEntity ToRepository(ArticleModel articleModel)
    {
        ArticleEntity articleEntity = new();
        articleEntity.Titlu = articleModel.Titlu;
        articleEntity.CategoryId = articleModel.Id;
        return articleEntity;
    }
}
