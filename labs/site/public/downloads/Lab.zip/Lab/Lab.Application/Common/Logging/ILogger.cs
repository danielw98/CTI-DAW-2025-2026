﻿namespace Lab.Application.Common.Logging;

public interface ILogger
{
    void Error(string message);
}
