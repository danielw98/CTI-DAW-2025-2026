﻿using Lab.Application.Common.DataAccess;

namespace Lab.Application.Common.Entities;

public class UserEntity : BaseEntity
{
    public string Name { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public List<ArticleEntity> Articles { get; set; } = [];
}
