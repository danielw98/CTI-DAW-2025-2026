﻿using Lab.Domain.Common.Exceptions;

namespace Lab.Domain.Core.Invoices;

public class InvoiceService
{
    List<string> Products { get; set; } = [];
    public int UserId { get; set; }

    public decimal Discount { get; set; }
    public void AddInvoice()
    {
        if (UserId > 10 && UserId < 20)
            Discount = 25.0M;
        
        throw new InvalidDiscountException();
    }
}
