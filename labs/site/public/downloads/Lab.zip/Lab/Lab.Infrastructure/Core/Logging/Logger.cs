﻿using Lab.Application.Common.Logging;

namespace Lab.Infrastructure.Core.Logging;

public class Logger : ILogger
{
    public void Error(string message)
    {
        Console.WriteLine(message);
    }
}
