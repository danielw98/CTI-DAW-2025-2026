﻿using Lab.Application.Common.DataAccess;
using Lab.Application.Common.Entities;
using Lab.DataAccess.Core.EfCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab.DataAccess.Core.Repositories;

public class ArticleRepository : IArticleRepository
{
    private readonly AppDbContext _appDbContext;

    public ArticleRepository(AppDbContext appDbContext)
    {
        _appDbContext = appDbContext;
    }

    public async Task AddAsync(ArticleEntity entity, CancellationToken cancellationToken)
    {
        await _appDbContext.Articles.AddAsync(entity, cancellationToken);
    }

    public void Delete(ArticleEntity entity)
    {
        _appDbContext.Articles.Remove(entity);
    }

    public async Task<List<ArticleEntity>> GetAllAsync()
    {
        return await _appDbContext.Articles.ToListAsync();
    }

    public Task<List<ArticleEntity>> GetAllWithDetailsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<List<ArticleEntity>> GetByCategoryAsync(int categoryId)
    {
        throw new NotImplementedException();
    }

    public Task<ArticleEntity?> GetByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<ArticleEntity?> GetByIdWithDetailsAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task SaveChangesAsync()
    {
        throw new NotImplementedException();
    }

    public void Update(ArticleEntity entity)
    {
        throw new NotImplementedException();
    }
}
