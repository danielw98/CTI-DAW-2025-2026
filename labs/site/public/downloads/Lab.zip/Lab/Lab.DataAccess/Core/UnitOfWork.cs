﻿using Lab.Application.Common.DataAccess;
using Lab.DataAccess.Core.EfCore;
using Lab.DataAccess.Core.Repositories;

namespace Lab.DataAccess.Core;

public class UnitOfWork : IUnitOfWork
{
    private readonly AppDbContext _appDbContext;

    public UnitOfWork(AppDbContext appDbContext)
    {
        _appDbContext = appDbContext;
    }

    public IArticleRepository ArticleRepository => new ArticleRepository(_appDbContext);

    public async Task SaveChangesAsync()
    {
        await _appDbContext.SaveChangesAsync();
    }
}
